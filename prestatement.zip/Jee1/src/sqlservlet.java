import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class sqlservlet extends GenericServlet {

	/**
	 *    
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletConfig conf=getServletConfig();
		String h=conf.getInitParameter("pr");
		String p=conf.getInitParameter("kr");
		PrintWriter out=resp.getWriter();
		out.println("<html><body bgcolor='red'>"+h+" "+p+"</body></html>");
		out.close();
	}

}
