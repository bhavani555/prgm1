package prestatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class pstDemo {

	public static void main(String[] args) throws SQLException  {
		// TODO Auto-generated method stub
		Connection con=null;
		String q="insert into school.student values(?,?,?)";
		PreparedStatement pst=con.prepareStatement(q);
try {
Class.forName("com.mysql.jdbc.Driver");

	con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=bhav");
	pst.setInt(1, 10);
	pst.setString(2, "pulla");
	pst.setDouble(3, 85.78);
	pst.setInt(1, 11);
	pst.setString(2, "barka");
	pst.setDouble(3, 95.78);
	pst.executeUpdate(q);
	System.out.println("multiple datas are inserted");
}
		catch(ClassNotFoundException | SQLException e )
		{
			e.printStackTrace();

				}
if(pst!=null)
{
	pst.close();
}
			if(con!=null)
				con.close();
			}
		
	}
		


