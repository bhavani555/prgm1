package jee2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class servlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Override
	protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException {
		String n=req.getParameter("nm");
		String i=req.getParameter("in");
		int y=Integer.parseInt(i);
		String p=req.getParameter("pl");
		String r=req.getParameter("pr");
		double d=Double.parseDouble(r);
		PrintWriter out=resp.getWriter();
		out.println("<html><body bgcolor='pink'>"+n+" "+p+"</body></html>");
		Connection con=null;
		PreparedStatement pst=null;
		String q="insert into ab.cd values(?,?,?,?)";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=bhav");
			pst=con.prepareStatement(q);
			pst.setString(1,n);
			pst.setInt(2,y);
			pst.setString(3,p);
			pst.setDouble(4,d);
			pst.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(pst!=null)
				try {
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		}
		
	}
	
	

