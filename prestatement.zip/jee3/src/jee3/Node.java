package jee3;

public class Node {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int data;
Node next;
public node(int data)
{

	this.data=data;
	next=null;
}
	}

}
