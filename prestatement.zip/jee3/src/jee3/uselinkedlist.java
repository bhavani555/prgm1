package jee3;

import java.util.Scanner;

public class uselinkedlist {
  Node head=null;
  Node next=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Node n2=takeInput();
print(n2);
System.out.println();
Node m=insert(n2,80,2);
print(m);
	}
	
private static Node insert(Node head, int pos, int data) {
		// TODO Auto-generated method stub
	Node n1=new node(data);
	int i=0;
	Node temp=head;
	while(i<pos-1)
	{
		temp=temp.next;
		i++;
	}
	n1.next=temp.next;
	temp.next=n1;
	
		return head;
	}
public static void print(Node head)
{Node next;
	while(head!=null)
	{
		System.out.println(head.data+" ");
		head=head.next;
	}
}
	private static Node takeInput() {
		// TODO Auto-generated method stub
		Node head=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter data");
		int data=sc.nextInt();
		while(data!=-1)
		{
			Node n1=new Node(data);
			if(head==null) {
				head=n1;
				}
			else
			{
				Node temp=head;
				while(temp.next!=null)
				{
					temp=temp.next;
				}
				temp.next=new Node(data);
			}
			data=sc.nextInt();
		}
		
		return head;
	}

}
