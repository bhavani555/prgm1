package jee3;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class doget extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws IOException {
	
		String i=req.getParameter("er");
		int ir=Integer.parseInt(i);
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String n=null;
		String p=null;
		String q="select * from ab.cd where id=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=bhav");
			pst=con.prepareStatement(q);
		
			pst.setInt(2,ir);
		
			rs=pst.executeQuery();
			if(rs.next())
			{
				n=rs.getString(1);
				n=rs.getString(3);
			}
				
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(pst!=null)
				try {
					pst.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		PrintWriter out=resp.getWriter();
out.println("<html><body bgcolor='red'>"+n+" "+p+"</body></html>");
out.close();
		}
		
	}
	
	



